def latest_fvg(df):
    if len(df) < 3:
        return None
    a, _, c = df.iloc[-3], df.iloc[-2], df.iloc[-1]
    # Bullish imbalance: current low above candle-1 high
    if float(c.low) > float(a.high):
        return {"type": "BULLISH_FVG", "low": float(a.high), "high": float(c.low)}
    # Bearish imbalance: current high below candle-1 low
    if float(c.high) < float(a.low):
        return {"type": "BEARISH_FVG", "low": float(c.high), "high": float(a.low)}
    return None
