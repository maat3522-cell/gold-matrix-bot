from dataclasses import dataclass
import pandas as pd

@dataclass
class StructureEvent:
    index: object
    kind: str
    level: float


def swings(df: pd.DataFrame, left: int = 2, right: int = 2):
    highs, lows = [], []
    h = df["high"].astype(float)
    l = df["low"].astype(float)
    for i in range(left, len(df)-right):
        if h.iloc[i] == h.iloc[i-left:i+right+1].max() and h.iloc[i] > h.iloc[i-left:i].max() and h.iloc[i] >= h.iloc[i+1:i+right+1].max():
            highs.append((df.index[i], float(h.iloc[i])))
        if l.iloc[i] == l.iloc[i-left:i+right+1].min() and l.iloc[i] < l.iloc[i-left:i].min() and l.iloc[i] <= l.iloc[i+1:i+right+1].min():
            lows.append((df.index[i], float(l.iloc[i])))
    return highs, lows


def bos_choch(df: pd.DataFrame, highs, lows):
    events = []
    last_high = highs[-1] if highs else None
    last_low = lows[-1] if lows else None
    for idx, row in df.iterrows():
        close = float(row.close)
        if last_high and close > last_high[1]:
            events.append(StructureEvent(idx, "BOS_UP", last_high[1]))
            last_high = None
        if last_low and close < last_low[1]:
            events.append(StructureEvent(idx, "BOS_DOWN", last_low[1]))
            last_low = None
    return events
