import pandas as pd
from .engine import analyze


def format_signal(s):
    if s["action"]=="NO TRADE":
        return f"GOLD MATRIX\nNO TRADE\nScore: {s['score']}\nReason: {s['reason']}"
    return (f"GOLD MATRIX\n{ s['action'] }\n\nEntry: {s['entry']:.2f}\nSL: {s['sl']:.2f}\nTP: {s['tp']:.2f}\nR:R: 1:{s['rr']:.1f}\nScore: {s['score']}\n{s['reason']}\n\nPAPER MODE")


def main(path="data.csv"):
    df=pd.read_csv(path, parse_dates=["time"] if "time" in pd.read_csv(path,nrows=0).columns else None)
    if "time" in df.columns:
        df=df.set_index("time")
    s=analyze(df)
    print(format_signal(s))

if __name__=="__main__":
    main()
