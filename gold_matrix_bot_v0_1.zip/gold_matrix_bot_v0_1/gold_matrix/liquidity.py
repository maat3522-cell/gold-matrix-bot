import pandas as pd

def detect_sweep(df: pd.DataFrame, lookback: int = 20):
    if len(df) < lookback + 1:
        return None
    x = df.iloc[-1]
    prior = df.iloc[-lookback-1:-1]
    prev_high = float(prior.high.max())
    prev_low = float(prior.low.min())
    if float(x.high) > prev_high and float(x.close) < prev_high:
        return {"type": "SELL_SIDE_LIQUIDITY_SWEEP", "level": prev_high}
    if float(x.low) < prev_low and float(x.close) > prev_low:
        return {"type": "BUY_SIDE_LIQUIDITY_SWEEP", "level": prev_low}
    return None


def previous_day_levels(df: pd.DataFrame):
    if not isinstance(df.index, pd.DatetimeIndex):
        return None
    days = df.index.normalize()
    if len(set(days)) < 2:
        return None
    current_day = days[-1]
    prev = df[days < current_day]
    if prev.empty:
        return None
    return {"PDH": float(prev.high.max()), "PDL": float(prev.low.min())}
