def rr(entry, sl, tp):
    risk = abs(entry-sl)
    return 0.0 if risk == 0 else abs(tp-entry)/risk


def levels(side, entry, structure_level, rr_target=2.0):
    entry=float(entry); structure_level=float(structure_level)
    if side == "BUY":
        sl=structure_level
        tp=entry + abs(entry-sl)*rr_target
    else:
        sl=structure_level
        tp=entry - abs(entry-sl)*rr_target
    return sl, tp, rr(entry, sl, tp)
