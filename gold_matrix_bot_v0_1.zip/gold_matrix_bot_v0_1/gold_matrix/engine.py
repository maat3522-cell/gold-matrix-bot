import pandas as pd
from .structure import swings, bos_choch
from .liquidity import detect_sweep
from .fvg import latest_fvg
from .risk import levels


def analyze(df: pd.DataFrame, min_score=12):
    required={"open","high","low","close"}
    missing=required-set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    if len(df)<30:
        return {"action":"NO TRADE","reason":"Not enough candles","score":0}

    highs,lows=swings(df)
    events=bos_choch(df,highs,lows)
    sweep=detect_sweep(df)
    fvg=latest_fvg(df)
    score=0; reasons=[]; side=None; entry=float(df.close.iloc[-1]); structure_sl=None

    if sweep:
        score += 5; reasons.append(sweep["type"])
        if sweep["type"]=="BUY_SIDE_LIQUIDITY_SWEEP":
            side="BUY"; structure_sl=sweep["level"]
        else:
            side="SELL"; structure_sl=sweep["level"]

    if events:
        e=events[-1]
        score += 4; reasons.append(e.kind)
        if side is None:
            side="BUY" if e.kind=="BOS_UP" else "SELL"

    if fvg:
        score += 3; reasons.append(fvg["type"])
        if side is None:
            side="BUY" if fvg["type"]=="BULLISH_FVG" else "SELL"

    # Basic trend confirmation from 20/50 EMA when enough data exists.
    close=df.close.astype(float)
    ema20=close.ewm(span=20, adjust=False).mean().iloc[-1]
    ema50=close.ewm(span=50, adjust=False).mean().iloc[-1]
    if side=="BUY" and ema20>ema50:
        score += 2; reasons.append("EMA20>EMA50")
    elif side=="SELL" and ema20<ema50:
        score += 2; reasons.append("EMA20<EMA50")

    if side is None or structure_sl is None or score < min_score:
        return {"action":"NO TRADE","score":score,"reason":" | ".join(reasons) or "No confluence"}

    sl,tp,rr_value=levels(side,entry,structure_sl,2.0)
    if rr_value < 2:
        return {"action":"NO TRADE","score":score,"reason":"R:R below threshold"}
    return {"action":side,"entry":entry,"sl":sl,"tp":tp,"rr":rr_value,"score":score,"reason":" | ".join(reasons)}
