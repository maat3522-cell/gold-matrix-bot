import pandas as pd
from gold_matrix.engine import analyze

def test_no_trade_short_data():
    df=pd.DataFrame({"open":[1]*10,"high":[2]*10,"low":[0]*10,"close":[1]*10})
    assert analyze(df)["action"]=="NO TRADE"
